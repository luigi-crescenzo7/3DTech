create definer = root@localhost trigger ordine_BEFORE_INSERT
    before insert
    on ordine
    for each row
BEGIN

END;

