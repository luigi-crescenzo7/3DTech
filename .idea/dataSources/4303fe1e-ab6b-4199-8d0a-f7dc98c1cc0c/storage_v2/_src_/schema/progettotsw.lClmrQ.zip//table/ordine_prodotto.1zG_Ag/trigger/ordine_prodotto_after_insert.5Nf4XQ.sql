create definer = root@localhost trigger ordine_prodotto_AFTER_INSERT
    after insert
    on ordine_prodotto
    for each row
BEGIN
	update ordine as ord set quantita = (select count(id_prodotto) from ordine_prodotto as op where op.id_ordine = ord.id_ordine);
END;

